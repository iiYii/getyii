<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=dbachina',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8mb4',
];
