<?php
return [
    'adminEmail' => 'ruyi1024@vip.126.com',
    'backupEmail' => 'ruyi1024@vip.126.com',
    'supportEmail' => 'ruyi1024@vip.126.com',
    'user.passwordResetTokenExpire' => 3600,
//    'avatarPath' => Yii::$app->basePath . '/uploads/avatars/',
//    'avatarUrl' => Yii::$app->urlManager->baseUrl . '/uploads/avatars/',
    'avatarPath' => '/web/uploads/avatars/',
    'avatarUrl' => '/uploads/avatars/',
    'avatarCachePath' => '/web/uploads/avatars/cache/',
    'avatarCacheUrl' => '/uploads/avatars/cache/',
    'icon-framework' => 'fa',  // Font Awesome Icon framework
    'qrCodePath' => '/web/uploads/qr-code/',
    'qrCodeUrl' => '/uploads/qr-code/',
];
