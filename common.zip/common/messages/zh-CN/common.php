<?php

return [
    'DELETED' => '已删除',
    'ACTIVE' => '正常',
    'EXCELLENT' => '推荐',
    'TOP' => '置顶',

    'Username' => '用户名/邮箱',
    'Password' => '密码',
    'Remember Me' => '记住我',
    'Incorrect username or password.' => '用户名密码验证失败。',
    'You don\'t have permission to login.' => '你没有登录权限。',
    'User ID' => '用户 ID',
    'Type' => '分类',
    'Merit' => '总值',
    'Created At' => '创建时间',
    'Updated At' => '更新时间',
    'Merit Template ID' => '模板ID',
    'Description' => '描述',
    'Action Type' => '操作类型  0减去 1新增',
    'Increment' => '变化值',


];