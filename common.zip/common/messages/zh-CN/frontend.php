<?php

return [
    'created_at {datetime}' => '于 {datetime} 发布',
    'reply_at {datetime}' => '于 {datetime} 回复',
    'last_by' => '最后由',

];