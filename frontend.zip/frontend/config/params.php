<?php
return [
    'adminEmail' => 'admin@example.com',
    'donateNode' => ['mysql','oracle','mongodb','lepus'], //开启打赏节点
    'donateTag' => ['求打赏', '技巧库'], //开启标签
    'LoginNode' => ['jobs','suggest'], //开启需要登录的节点
    'setting' => [
        'xunsearch' => false, // true 表示开启 GetYii xunsearch 搜索功能，默认不开启
    ],
];
