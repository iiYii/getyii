<?php

namespace frontend\modules\nav;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\nav\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
