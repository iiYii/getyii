<?php

namespace frontend\modules\question;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\question\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
