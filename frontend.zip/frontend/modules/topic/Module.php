<?php

namespace frontend\modules\topic;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\topic\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
