<?php

namespace frontend\modules\tweet;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\tweet\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
