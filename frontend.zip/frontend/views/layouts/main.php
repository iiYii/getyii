<?php
use frontend\assets\AppAsset;
use frontend\assets\BowerAsset;
use frontend\widgets\Alert;
use frontend\assets\EmojifyAsset;
use frontend\assets\LayuiAsset;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\Breadcrumbs;


/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
BowerAsset::register($this);
LayuiAsset::register($this);

\frontend\assets\EditorAsset::register($this);
$emojify = EmojifyAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?> - <?= \Yii::$app->setting->get('siteTitle') ?></title>
    <meta name="keywords" content="<?= \Yii::$app->setting->get('siteKeyword') ?>"/>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<div class="wrap" id="wrap">

    <?= \frontend\widgets\Nav::widget(); ?>

    <div class="container" style="padding-top: 110px;">
        <div class="row">
            <?= Breadcrumbs::widget([
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ]) ?>
            <?= Alert::widget() ?>
            <?= $content ?>
        </div>
    </div>
</div>


<footer class="footer">

    <div class="container">
        <div class="row">
            <dl class="col-sm-2">
                <dt>网站信息</dt>
                <dd><a href="<?= Url::to(['/site/about']) ?>">关于我们</a></dd>
                <dd><a href="<?= Url::to(['/site/contributors']) ?>">贡献者</a></dd>
            </dl>
            <dl class="col-sm-2">
                <dt>相关合作</dt>
                <dd><a href="<?= Url::to(['/site/contact']) ?>">联系我们</a></dd>
            </dl>
            <dl class="col-sm-2">
                <dt>关注我们</dt>
                <dd><a href="<?= Url::to(['/site/timeline']) ?>">时间线</a></dd>
            </dl>
            <dl class="col-sm-3">
                <dt> 技术采用</dt>
                <dd class="fs12">
                    网站由 <a href="http:www.dba-china.com">DBA-CHINA</a> 创建 项目源码地址: <a href="https://github.com/iiyii/getyii">GetYii</a>
                    <br/>
                    <?= Yii::powered() ?> <?= Yii::getVersion() ?>
                    <br/>
                    &copy; <?= \Yii::$app->setting->get('siteName') ?> <?= date('Y') ?>&nbsp;•&nbsp; <?= floor(Yii::getLogger()->getElapsedTime() * 1000).' ms';?>
                </dd>
            </dl>
            <div class="col-sm-3">
                <a href="http://ytuninfo.com/" target="_blank">
                    <img src="http://cache.dba-china.com/images/qrcode_tunyun.jpg" alt="qiniu" width="180">
                </a>
                <p>Oracle干货天天看(合作伙伴公众号)</p>
            </div>
        </div>
    </div>
</footer>

<div class="btn-group-vertical" id="floatButton">
    <button type="button" class="btn btn-default" id="goTop" title="去顶部"><span
            class="glyphicon glyphicon-arrow-up"></span></button>
    <button type="button" class="btn btn-default" id="refresh" title="刷新"><span
            class="glyphicon glyphicon-repeat"></span></button>
    <button type="button" class="btn btn-default" id="pageQrcode" title="本页二维码"><span
            class="glyphicon glyphicon-qrcode"></span>
        <img class="qrcode" width="130" height="130" src="<?= Url::to(['/site/qrcode', 'url' => Yii::$app->request->absoluteUrl])?>" />
    </button>
    <button type="button" class="btn btn-default" id="goBottom" title="去底部"><span
            class="glyphicon glyphicon-arrow-down"></span></button>
</div>

<div style="display:none">
    <?= \Yii::$app->setting->get('siteAnalytics'); ?>
</div>

<?php
$this->registerJs(
    'Config = {emojiBaseUrl: "' . $emojify->baseUrl . '"};',
    \yii\web\View::POS_HEAD
);
?>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
