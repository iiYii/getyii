<?php
/**
 * author     : forecho <caizhenghai@gmail.com>
 * createTime : 15/4/12 上午10:38
 * description: Markdown 提示
 */
?>
<div id="reply-notice" style="display:none">
    <ul>
        <li><?= \Yii::t('app', 'publish_typography'); ?></li>
        <li><?= \Yii::t('app', 'publish_markdown'); ?></li>
<!--        <li>--><?//= \Yii::t('app', 'publish_emoji'); ?><!--</li>-->
        <li><?= \Yii::t('app', 'publish_at_user'); ?></li>
        <li><?= \Yii::t('app', 'publish_image'); ?></li>
    </ul>
</div>